import { NavLink } from 'react-router-dom'
import {
  BrainCircuit, Briefcase, GitCompareArrows, LayoutDashboard, Target, Users, X, Sparkles,
} from 'lucide-react'

export const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/jobs', label: 'Jobs', icon: Briefcase },
  { to: '/candidates', label: 'Candidates', icon: Users },
  { to: '/matching', label: 'Matching', icon: Target },
  { to: '/ai', label: 'AI Intelligence', icon: Sparkles },
  { to: '/compare', label: 'Compare', icon: GitCompareArrows },
]

interface SidebarProps { open: boolean; onClose: () => void }

export function Sidebar({ open, onClose }: SidebarProps) {
  return (
    <>
      {/* Dark overlay behind the drawer on mobile */}
      {open && (
        <div className="fixed inset-0 z-30 animate-fade-in bg-black/60 lg:hidden" onClick={onClose} aria-hidden />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-white/[0.06] bg-navy-900/95 backdrop-blur transition-transform duration-300 lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center justify-between px-5">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-indigo-500 text-white shadow-lg shadow-brand-600/30">
              <BrainCircuit size={20} />
            </span>
            <span className="text-lg font-semibold tracking-tight text-white">
              Neural<span className="text-brand-400">Hire</span>
            </span>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/5 lg:hidden" aria-label="Close menu">
            <X size={18} />
          </button>
        </div>

        <nav className="mt-4 flex-1 space-y-1 px-3">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                  isActive
                    ? 'bg-brand-500/15 text-white ring-1 ring-brand-500/30'
                    : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                }`
              }
            >
              <Icon size={18} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="m-3 rounded-xl border border-brand-500/20 bg-gradient-to-br from-brand-600/20 to-indigo-600/10 p-4">
          <p className="text-xs font-semibold text-brand-300">AI-powered screening</p>
          <p className="mt-1 text-xs leading-relaxed text-slate-400">
            Upload resumes and rank candidates against any job description.
          </p>
        </div>
      </aside>
    </>
  )
}
