import { Briefcase, Target, UserCheck, Users } from 'lucide-react'
import { PipelineChart, ScoreChart, SkillsChart, TrendChart } from '../components/dashboard/Charts'
import { TopMatches } from '../components/dashboard/TopMatches'
import { Card } from '../components/ui/Card'
import { DemoBadge } from '../components/ui/DemoBadge'
import { StatCard } from '../components/ui/StatCard'
import {
  demoPipeline, demoScores, demoSkills, demoStats, demoTopMatches, demoTrend,
} from '../data/demoData'

const statIcons = [Briefcase, Users, Target, UserCheck]

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="animate-fade-up">
          <h1 className="text-2xl font-semibold tracking-tight text-white">Recruiter Dashboard</h1>
          <p className="mt-1 text-sm text-slate-400">Hiring pipeline, match quality and skill trends at a glance.</p>
        </div>
        <DemoBadge label="Demo data · live analytics arrive in a later module" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {demoStats.map((s, i) => (
          <StatCard key={s.label} stat={s} icon={statIcons[i]} delay={i * 60} />
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3" title="Applications this week" subtitle="Applications received vs. shortlisted" delay={120}>
          <TrendChart data={demoTrend} />
        </Card>
        <Card className="lg:col-span-2" title="Match score distribution" subtitle="Candidates per score range" delay={180}>
          <ScoreChart data={demoScores} />
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Hiring pipeline" subtitle="Candidates by stage" delay={240}>
          <PipelineChart data={demoPipeline} />
        </Card>
        <Card title="Skill demand vs supply" subtitle="Where the talent gap is" delay={300}>
          <SkillsChart data={demoSkills} />
        </Card>
        <Card title="Top matches" subtitle="Highest compatibility scores" delay={360}>
          <TopMatches matches={demoTopMatches} />
        </Card>
      </div>
    </div>
  )
}
